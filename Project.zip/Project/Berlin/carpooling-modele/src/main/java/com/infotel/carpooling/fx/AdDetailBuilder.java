package com.infotel.carpooling.fx;

import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

public class AdDetailBuilder implements UIBuilder {
	
	private Label departureLabel;
	private Label departureText;
	private Label arrivalLabel;
	private Label arrivalText;
	private Label memberNameText;
	private AnchorPane adDetailPane;
	private TextArea commentTextArea;
	private Button validateButton;
	private Button refuseButton;
	private HBox buttonBox;
	private VBox detailBox;
	private Label detailTitleLabel;

	
	@Override
	public Parent getContainer() {
		return detailBox;
	}

	@Override
	public void addListener() {
		validateButton.setOnMouseClicked(e -> System.out.println("VALIDER"));
	}

	@Override
	public void buildUI() {
		detailTitleLabel = new Label("Détail");
		
		departureLabel = new Label("Départ :");
		departureText = new Label("-");
		arrivalLabel = new Label("Arrivée :");
		arrivalText = new Label("-");
		
		memberNameText = new Label("Elise Perrot");
		
		AnchorPane.setLeftAnchor(departureLabel, 10.0);
		AnchorPane.setTopAnchor(departureLabel, 10.0);
		
		AnchorPane.setLeftAnchor(departureText, 100.0);
		AnchorPane.setTopAnchor(departureText, 10.0);
		
		AnchorPane.setLeftAnchor(arrivalLabel, 180.0);
		AnchorPane.setTopAnchor(arrivalLabel, 10.0);
		
		AnchorPane.setLeftAnchor(arrivalText, 280.0);
		AnchorPane.setTopAnchor(arrivalText, 10.0);
		
		AnchorPane.setLeftAnchor(memberNameText, 10.0);
		AnchorPane.setTopAnchor(memberNameText, 80.0);
	
		adDetailPane = new AnchorPane(
				departureLabel,
				departureText,
				arrivalLabel,
				arrivalText,
				memberNameText
		);
		
		commentTextArea = new TextArea();
		validateButton = new Button("Valider");
		refuseButton = new Button("Refuser");
		buttonBox = new HBox(
				validateButton,
				refuseButton
		);
		//buttonBox.setStyle("-fx-background-color: green;");
		buttonBox.setSpacing(10);
		buttonBox.setAlignment(Pos.CENTER);
		
		
		detailBox = new VBox(
				detailTitleLabel,
				adDetailPane,
				commentTextArea,
				buttonBox
		);
		detailBox.setSpacing(10);
	}

}
