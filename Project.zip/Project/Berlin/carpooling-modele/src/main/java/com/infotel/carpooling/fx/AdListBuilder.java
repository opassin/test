package com.infotel.carpooling.fx;

import com.infotel.carpooling.fx.model.Ad;
import com.infotel.carpooling.fx.service.AdService;

import javafx.collections.ObservableList;
import javafx.scene.Parent;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.layout.VBox;

public class AdListBuilder implements UIBuilder{
	
	private ListView<Ad> adListView;
	private Label adListTitleLabel;
	private VBox adListBox;

	
	@Override
	public Parent getContainer() {
		return adListBox;
	}
	
	@Override
	public void buildUI() {
		
		try {
			
			adListView = new ListView<>();
			adListTitleLabel = new Label("liste des annonces");
			
			adListBox = new VBox(
					adListTitleLabel,
					adListView
			);
			adListBox.setSpacing(10);
			
			AdService service = new AdService();
			ObservableList<Ad> ads = service.loadAds();
			adListView.setItems(ads);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
	}

}
