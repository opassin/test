package com.infotel.carpooling.fx;

import javafx.application.Application;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class CarpoolingApp extends Application {

	@Override
	public void start(Stage stage) throws Exception {
		
		// Liste des annonces
		AdListBuilder adListBuilder = new AdListBuilder();
		Parent adListBox = adListBuilder.build();
		
		// Détail d'une annonce
		UIBuilder adDetailBuilder = new AdDetailBuilder();
		Parent detailBox = adDetailBuilder.build();
		
		// Layout global
		MainPaneBuilder mainPaneBuilder = new MainPaneBuilder(adListBox, detailBox);
		Parent rootBox = mainPaneBuilder.build();
		
		Scene scene = new Scene(rootBox);
		stage.setScene(scene);
		stage.setTitle("En voiture Simone !");
		
		stage.show();

	}

}
