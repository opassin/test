package com.infotel.carpooling.fx;

import java.util.List;

import com.infotel.carpooling.fx.model.Ad;
import com.infotel.carpooling.fx.model.Login;
import com.infotel.carpooling.fx.xml.AdsToValidateResponseDomReader;
import com.infotel.carpooling.fx.xml.AdsToValidateResponseReader;
import com.infotel.carpooling.fx.xml.LoginRequestDom4jWriter;
import com.infotel.carpooling.fx.xml.LoginRequestWriter;

public class Main {
	
	public static void main0(String[] args) throws Exception {
		AdsToValidateResponseReader reader = new AdsToValidateResponseDomReader();
		
		List<Ad> ads = reader.read("xml\\AdsToValidateResponse.xml");
		
		System.out.println("\r\nRésultat:");
		ads.stream().forEach(System.out::println);
	}
	
	public static void main1(String[] args) throws Exception {
		LoginRequestWriter writer = new LoginRequestDom4jWriter();
		Login login = new Login();
		login.setUsername("Marius");
		login.setPassword("secret");
		
		writer.write(login);
	}
	
	public static void main2(String[] args) {
//		AdsToValidateResponseReaderFactory factory = new AdsToValidateResponseReaderFactory();
//		
//		AdsToValidateResponseReader reader 
	
	}
	
	public static void main(String[] args) {
		CarpoolingApp.launch(CarpoolingApp.class, args);
	}

}
