package com.infotel.carpooling.fx;

import javafx.geometry.Insets;
import javafx.scene.Parent;
import javafx.scene.layout.HBox;

public class MainPaneBuilder implements UIBuilder {
	
	private Parent adListBox;
	private Parent detailBox;	
	private HBox rootBox;
	
	public MainPaneBuilder(Parent adListBox, Parent detailBox) {
		super();
		this.adListBox = adListBox;
		this.detailBox = detailBox;
	}

	public Parent build(Parent adListBox, Parent detailBox) {
		
		return getContainer();
	}

	@Override
	public void buildUI() {
		// TODO Auto-generated method stub
		rootBox = new HBox(
				adListBox,
				detailBox
				);
		rootBox.setSpacing(10);
		rootBox.setPadding(new Insets(10));
		
	}

	@Override
	public Parent getContainer() {
		// TODO Auto-generated method stub
		return rootBox;
	}

}
