package com.infotel.carpooling.fx;

import javafx.scene.Parent;

public interface UIBuilder {

	void buildUI();

	default void addListener() {}

	Parent getContainer();

	default Parent build() {
		buildUI();
		
		addListener();
		
		return getContainer();
	}

}