package com.infotel.carpooling.fx.model;

import java.time.LocalDateTime;

public class Ad {
	
	private int id;
	private String advertisement;
	private int seatingCapacity;
	private LocalDateTime departure;
	private LocalDateTime arrival;
	private int price;
	
	private City from;
	private City to;
	private Member member;
	
	
	@Override
	public String toString() {
		return "Ad [id=" + id + ", advertisement=" + advertisement + ", seatingCapacity=" + seatingCapacity
				+ ", departure=" + departure + ", arrival=" + arrival + ", price=" + price + ", from=" + from + ", to="
				+ to + ", member=" + member + "]";
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getAdvertisement() {
		return advertisement;
	}
	public void setAdvertisement(String advertisement) {
		this.advertisement = advertisement;
	}
	public int getSeatingCapacity() {
		return seatingCapacity;
	}
	public void setSeatingCapacity(int seatingCapacity) {
		this.seatingCapacity = seatingCapacity;
	}
	public LocalDateTime getDeparture() {
		return departure;
	}
	public void setDeparture(LocalDateTime departure) {
		this.departure = departure;
	}
	public LocalDateTime getArrival() {
		return arrival;
	}
	public void setArrival(LocalDateTime arrival) {
		this.arrival = arrival;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public City getFrom() {
		return from;
	}
	public void setFrom(City from) {
		this.from = from;
	}
	public City getTo() {
		return to;
	}
	public void setTo(City to) {
		this.to = to;
	}
	public Member getMember() {
		return member;
	}
	public void setMember(Member member) {
		this.member = member;
	}
	
	

}
