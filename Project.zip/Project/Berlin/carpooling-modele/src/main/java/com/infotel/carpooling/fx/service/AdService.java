package com.infotel.carpooling.fx.service;

import java.util.List;

import com.infotel.carpooling.fx.model.Ad;
import com.infotel.carpooling.fx.xml.AdsToValidateResponseReader;
import com.infotel.carpooling.fx.xml.AdsToValidateResponseReaderFactory;
import com.infotel.carpooling.fx.xml.AdsToValidateResponseReaderFactory.ReaderType;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class AdService {
	
	public ObservableList<Ad> loadAds() throws Exception {
		AdsToValidateResponseReader reader = AdsToValidateResponseReaderFactory.Instance.getReader(ReaderType.Sax);
		
		List<Ad> ads = reader.read("xml\\AdsToValidateResponse.xml");
		
		ObservableList<Ad> result = FXCollections.observableArrayList(ads);
		
		return result;
	}

}
