package com.infotel.carpooling.fx.xml;

import java.time.LocalDateTime;
import java.util.LinkedList;
import java.util.List;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import com.infotel.carpooling.fx.model.Ad;
import com.infotel.carpooling.fx.model.City;
import com.infotel.carpooling.fx.model.Member;

public class AdsHandler extends DefaultHandler {
	
	private List<Ad> ads;
	private String currentNode;

	@Override
	public void startDocument() throws SAXException {
		System.out.println("START DOC");
		ads = new LinkedList<>();
	}
	
	@Override
	public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
		System.out.println("START ELEMENT " + qName);
		
		switch (qName) {
		case "Ad":
			Ad ad = new Ad();
			
			int id = Integer.parseInt(attributes.getValue("id"));
			ad.setId(id);
			
			ads.add(ad);
			
			break;
		case "Advertisement":
			currentNode = "Advertisement";
			break;
		case "SeatingCapacity":
			currentNode = "SeatingCapacity";
			break;
		case "From":
			int idFrom= Integer.parseInt(attributes.getValue("id"));
			String nameFrom = attributes.getValue("name");
			
			City fromCity = new City();
			fromCity.setId(idFrom);
			fromCity.setName(nameFrom);
			
			Ad ad2 = ads.get(ads.size() - 1);
			ad2.setFrom(fromCity);
			break;
		case "To":
			int idTo= Integer.parseInt(attributes.getValue("id"));
			String nameTo = attributes.getValue("name");
			
			City toCity = new City();
			toCity.setId(idTo);
			toCity.setName(nameTo);
			
			Ad ad3 = ads.get(ads.size() - 1);
			ad3.setTo(toCity);
			break;
		case "Departure":
			currentNode = "Departure";
			break;
		case "Arrival":
			currentNode = "Arrival";
			break;
		case "Price":
			currentNode = "Price";
			break;
		case "Member":
			String username=attributes.getValue("id");
			Member member = new Member();
			member.setUsername(username);
			
			Ad ad4 = ads.get(ads.size() - 1);
			ad4.setMember(member);
			break;
		case "FirstName":
			currentNode = "FirstName";
			break;
		case "LastName":
			currentNode = "LastName";
			break;
		default:
			break;
		}
		
		
	}
	
	@Override
	public void characters(char[] ch, int start, int length) throws SAXException {
		
		if (currentNode == null) return;
		
		String text = new String(ch, start, length);
		System.out.println(text);
		
		switch (currentNode) {
		
		case "Advertisement":
			Ad ad = ads.get(ads.size() - 1);
			ad.setAdvertisement(text);
			currentNode = null;
			break;
			
		case "SeatingCapacity":
			Ad ad2 = ads.get(ads.size() - 1);
			ad2.setSeatingCapacity(Integer.parseInt(text));
			currentNode = null;
			break;
			
		case "Departure":
			Ad ad3 = ads.get(ads.size() - 1);
			ad3.setDeparture(LocalDateTime.parse(text));
			currentNode = null;
			break;
		
		case "Arrival":
			Ad ad4 = ads.get(ads.size() - 1);
			ad4.setArrival(LocalDateTime.parse(text));
			currentNode = null;
			break;
			
		case "Price":
			Ad ad5 = ads.get(ads.size() - 1);
			ad5.setPrice(Integer.parseInt(text));
			currentNode = null;
			break;
//		case "FirstName":
//			Ad ad6 = ads.get(ads.size() - 1);
//			Member memb = ad6.getMember();
//			System.out.println(memb.toString());
//			memb.setFirstName(text);
//			currentNode = null;
//			break;
//		case "LastName":
//			Ad ad7 = ads.get(ads.size() - 1);
//			ad7.getMember().setLastName(text);
//			currentNode = null;
//			break;
		default:
			break;
		}
		
		
	}
	
	@Override
	public void endElement(String uri, String localName, String qName) throws SAXException {
		System.out.println("END ELEMENT " + qName);
	}

	public List<Ad> getAds() {
		return ads;
	}
	
	

}