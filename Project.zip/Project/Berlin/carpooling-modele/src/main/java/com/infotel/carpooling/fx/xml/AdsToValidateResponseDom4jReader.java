package com.infotel.carpooling.fx.xml;

import java.io.File;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

import com.infotel.carpooling.fx.model.Ad;
import com.infotel.carpooling.fx.model.City;
import com.infotel.carpooling.fx.model.Member;

public class AdsToValidateResponseDom4jReader implements AdsToValidateResponseReader {

	@Override
	public List<Ad> read(String filename) throws Exception {
		List<Ad> ads = new ArrayList<>();
		
		SAXReader reader = new SAXReader();
		Document doc = reader.read(new File(filename));
		
		Element rootElt = doc.getRootElement();
		
		rootElt.elements("Ad").forEach(adElt -> {
			Ad ad = new Ad();
			ad.setId(Integer.parseInt(adElt.attributeValue("id")));
		   
			String textAdvertisement = adElt.elementText("Advertisement");
			ad.setAdvertisement(textAdvertisement);
			
			String textCapacity = adElt.elementText("SeatingCapacity");
			ad.setSeatingCapacity(Integer.parseInt(textCapacity));
			
			City fromCity = new City();
			String textIdFrom = adElt.elements("From").get(0).attributeValue("id");
			String textNameFrom = adElt.elements("From").get(0).attributeValue("name");
			fromCity.setId(Integer.parseInt(textIdFrom));
			fromCity.setName(textNameFrom);
			ad.setFrom(fromCity);
			
			City toCity = new City();
			String textIdTo = adElt.elements("To").get(0).attributeValue("id");
			String textNameTo = adElt.elements("To").get(0).attributeValue("name");
			toCity.setId(Integer.parseInt(textIdTo));
			toCity.setName(textNameTo);
			ad.setTo(toCity);
			
			String textDeparture = adElt.elementText("Departure");
			ad.setDeparture(LocalDateTime.parse(textDeparture));
			
			String textArrival = adElt.elementText("Arrival");
			ad.setArrival(LocalDateTime.parse(textArrival));
			
			String textPrice = adElt.elementText("Price");
			ad.setPrice(Integer.parseInt(textPrice));
			
			Member member = new Member();
			Element memberElt = adElt.elements("Member").get(0);
			member.setUsername(memberElt.attributeValue("id"));
			String textFirstName = memberElt.elementText("FirstName");
			String textLastName = memberElt.elementText("LastName");
			member.setFirstName(textFirstName);
			member.setLastName(textLastName);
			ad.setMember(member);
			
			ads.add(ad);
		});
		
		return ads;
	}

}
