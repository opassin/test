package com.infotel.carpooling.fx.xml;

import java.io.FileInputStream;
import java.io.InputStream;
import java.time.LocalDateTime;
import java.util.LinkedList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.infotel.carpooling.fx.model.Ad;
import com.infotel.carpooling.fx.model.City;
import com.infotel.carpooling.fx.model.Member;

public class AdsToValidateResponseDomReader implements AdsToValidateResponseReader {

	@Override
	public List<Ad> read(String filename) throws Exception {
		
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder = factory.newDocumentBuilder();
		
		InputStream is = new FileInputStream(filename);
		Document doc = builder.parse(is);
		
		List<Ad> ads = new LinkedList<>();
		
		Element rootElt = doc.getDocumentElement();
		
		NodeList adNodes = rootElt.getElementsByTagName("Ad");
		
		for (int i = 0; i < adNodes.getLength(); i++) {
			
			Ad ad = new Ad();
			Element adElt = (Element) adNodes.item(i);
			ad.setId(Integer.parseInt(adElt.getAttribute("id")));
			
			Element advertisementElt = (Element)adElt.getElementsByTagName("Advertisement").item(0);
			ad.setAdvertisement(advertisementElt.getTextContent());
			
			Element seatingCapacityElt = (Element)adElt.getElementsByTagName("SeatingCapacity").item(0);
			ad.setSeatingCapacity(Integer.parseInt(seatingCapacityElt.getTextContent()));
			
			Element fromElement = (Element)adElt.getElementsByTagName("From").item(0);
			City fromCity = new City();
			fromCity.setId(Integer.parseInt(fromElement.getAttribute("id")));
			fromCity.setName(fromElement.getAttribute("name"));
			ad.setFrom(fromCity);
			
			Element toElement = (Element)adElt.getElementsByTagName("To").item(0);
			City toCity = new City();
			toCity.setId(Integer.parseInt(toElement.getAttribute("id")));
			toCity.setName(toElement.getAttribute("name"));
			ad.setTo(toCity);
			
			Element departureElt = (Element)adElt.getElementsByTagName("Departure").item(0);
			ad.setDeparture(LocalDateTime.parse(departureElt.getTextContent()));
			
			Element arrivalElt = (Element)adElt.getElementsByTagName("Arrival").item(0);
			ad.setArrival(LocalDateTime.parse(arrivalElt.getTextContent()));
			
			Element priceElt = (Element)adElt.getElementsByTagName("Price").item(0);
			ad.setPrice(Integer.parseInt(priceElt.getTextContent()));
			
			Element memberElt = (Element)adElt.getElementsByTagName("Member").item(0);
			Member member = new Member();
			member.setUsername(memberElt.getAttribute("id"));
			member.setFirstName(memberElt.getElementsByTagName("FirstName").item(0).getTextContent());
			member.setLastName(memberElt.getElementsByTagName("LastName").item(0).getTextContent());
			ad.setMember(member);
			
			ads.add(ad);
		}
		
		return ads;
	}

}
