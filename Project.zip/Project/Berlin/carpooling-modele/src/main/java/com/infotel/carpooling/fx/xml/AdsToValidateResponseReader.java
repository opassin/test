package com.infotel.carpooling.fx.xml;

import java.util.List;

import com.infotel.carpooling.fx.model.Ad;

public interface AdsToValidateResponseReader {

	List<Ad> read(String filename) throws Exception;

}