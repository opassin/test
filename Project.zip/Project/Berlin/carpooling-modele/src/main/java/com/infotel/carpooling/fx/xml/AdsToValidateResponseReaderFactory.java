package com.infotel.carpooling.fx.xml;

public enum AdsToValidateResponseReaderFactory {
	
	Instance;
	
	public enum ReaderType {Sax, Dom, Dom4J};
	
	public AdsToValidateResponseReader getReader(ReaderType type) {
		
		switch (type) {
		case Sax:
			return new AdsToValidateResponseSaxReader();
		case Dom:
			return new AdsToValidateResponseDomReader();
		case Dom4J:
			return new AdsToValidateResponseDom4jReader();
		}
		return null;
	}

}
