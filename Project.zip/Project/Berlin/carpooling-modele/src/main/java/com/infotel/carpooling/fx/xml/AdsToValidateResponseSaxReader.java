package com.infotel.carpooling.fx.xml;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.LinkedList;
import java.util.List;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import com.infotel.carpooling.fx.model.Ad;

public class AdsToValidateResponseSaxReader implements AdsToValidateResponseReader {
	
	
	public List<Ad> read(String filename) throws Exception{
		SAXParserFactory factory = SAXParserFactory.newInstance();
		SAXParser parser = factory.newSAXParser();
		
		AdsHandler handler = new AdsHandler();
		
		InputStream is = new FileInputStream(filename);
		
		parser.parse(is, handler);
		
		List<Ad> ads = handler.getAds();
		
		return ads;
	}
}
