package com.infotel.carpooling.fx.xml;

import java.io.FileWriter;

import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.Namespace;
import org.dom4j.QName;

import com.infotel.carpooling.fx.model.Login;

public class LoginRequestDom4jWriter implements LoginRequestWriter {

	@Override
	public void write(Login login) throws Exception {
		
		Document doc = DocumentHelper.createDocument();
		
		Namespace namespace = new Namespace(null, "http://www.infotel.com/carpooling");
		
		Element rootElt = doc.addElement(new QName("LoginRequest", namespace));
		rootElt.addElement("Username").setText(login.getUsername());
		rootElt.addElement("Password").setText(login.getPassword());
		
		FileWriter writer = new FileWriter("xml\\LoginRequestDom4j.xml");
		doc.write(writer);
		writer.close();

	}

}
