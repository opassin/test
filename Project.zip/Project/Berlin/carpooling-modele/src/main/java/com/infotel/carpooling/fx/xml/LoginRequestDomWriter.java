package com.infotel.carpooling.fx.xml;

import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.infotel.carpooling.fx.model.Login;

public class LoginRequestDomWriter implements LoginRequestWriter {

	@Override
	public void write(Login login) throws Exception {
		// TODO Auto-generated method stub
		
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder = factory.newDocumentBuilder();
		
		Document doc = builder.newDocument();

		Element rootElt = doc.createElement("LoginRequest");
		doc.appendChild(rootElt);
		
		Element usernameElt = doc.createElement("Username");
		usernameElt.setTextContent(login.getUsername());
		rootElt.appendChild(usernameElt);
		
		Element passwordElt = doc.createElement("Password");
		passwordElt.setTextContent(login.getPassword());
		rootElt.appendChild(passwordElt);
		
		TransformerFactory transformerFactory = TransformerFactory.newInstance();
		Transformer transformer = transformerFactory.newTransformer();
		
		Source source = new DOMSource(doc);
		Result result = new StreamResult(new File("xml\\LoginRequestDom.xml"));
		//Result result = new StreamResult(System.out);
		
		transformer.transform(source, result);
	}

}
