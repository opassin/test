package com.infotel.carpooling.fx.xml;

import com.infotel.carpooling.fx.model.Login;

public interface LoginRequestWriter{
	
	public void write(Login login) throws Exception;

}
